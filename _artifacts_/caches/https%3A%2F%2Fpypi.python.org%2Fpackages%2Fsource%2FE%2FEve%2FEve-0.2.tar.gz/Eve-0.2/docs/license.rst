.. _license:

Licensing
=========

Authors
-------

.. include:: ../AUTHORS

BSD License
-----------

.. include:: ../LICENSE

Artwork License
---------------
Eve artwork 2013 by Roberto Pasini "Kalamun" released under the `Creative
Commons BY-SA`_ license.

.. _`Creative Commons BY-SA`: https://github.com/nicolaiarocci/eve/blob/develop/artwork/LICENSE
