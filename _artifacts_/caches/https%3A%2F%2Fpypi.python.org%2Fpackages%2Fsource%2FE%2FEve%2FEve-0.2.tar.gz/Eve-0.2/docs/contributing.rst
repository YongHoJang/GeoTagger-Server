.. _contributing:

.. include:: ../contributing.rst

